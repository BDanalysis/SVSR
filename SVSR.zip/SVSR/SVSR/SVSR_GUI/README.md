# SVSR_GUI
variant simulator with GUI
